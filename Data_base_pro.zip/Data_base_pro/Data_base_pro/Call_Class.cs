﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Data_base_pro
{
    class Call_Class
    {
        static void Main()
        {
         //   Employee emp = new Employee();
            EmployeeDal ed = new EmployeeDal();
            //List<Employee> list = ed.GetAllEmployees();
            //for (int i=0;i<list.Count;i++)
            //{
            //    Console.WriteLine(list[i].Emp_ID+" "+ list[i].Emp_Name +" "+list[i].Emp_Contact +" "+list[i].Salary);
            //}
            Employee emp = new Employee();
            emp.Emp_ID = 2;
            emp.Emp_Name = "Max Sandel";
            emp.Emp_Contact = "8745678939";
            emp.Salary = "15000";
            emp.Did = 109;
            //  Console.WriteLine(ed.AddEmployee(emp));
            /* if(ed.Update(emp))
             {
                 Console.WriteLine("Data updated successfully");
             }
             else
             {
                 Console.WriteLine("Error!");
             }
             */
            /*   if(ed.Delete(4))
               {
                   Console.WriteLine("Data deleted successfully");
               }
               else
               {
                   Console.WriteLine("Error!");
               }
               */
            Employee emp1 = ed.search(4);
            Console.Write(emp1.Emp_ID+" "+emp1.Emp_Name);
        }
    }
}
