﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;

namespace Data_base_pro
{
    class EmployeeDal
    {
        public List<Employee> GetAllEmployees()
        {
            SqlConnection con = null;
            List<Employee> list = null;
            try
            {
                 list= new List<Employee>();
                con= new SqlConnection();
                con.ConnectionString = "Server=.;Initial Catalog=Northwind;User Id=sa;Password=wipro@123";
                SqlCommand cmd = new SqlCommand();
                cmd.CommandText = "select * from employee";
                cmd.Connection = con;
                con.Open();
                SqlDataReader sqldr = cmd.ExecuteReader();
                if (sqldr.HasRows)
                {
                    while (sqldr.Read())
                    {
                        Employee emp = new Employee();
                        emp.Emp_ID = int.Parse(sqldr["emp_id"].ToString());
                        emp.Emp_Name = sqldr["emp_name"].ToString();
                        emp.Emp_Contact = sqldr["emp_contact"].ToString();
                        emp.Salary = sqldr["salary"].ToString();
                        list.Add(emp);
                    }
                }               
                
            }
            catch(Exception e)
            {
                Console.WriteLine(e.Message);
            }
            finally
            {
                con.Close();
            }
            return list;
        }

        public int AddEmployee(Employee emp)
        {
            int n = 0;
            SqlConnection con = null;
            try
            {
                con = new SqlConnection();
                con.ConnectionString = "Server=.;Initial Catalog=Northwind;User Id=sa;Password=wipro@123";
                SqlCommand cmd = new SqlCommand();
                cmd.CommandText = "insert into employee(emp_id,emp_name,emp_contact,salary,dept_no) values (@id,@name,@contact,@salary,@did);select SCOPE_IDENTITY()";
                cmd.Parameters.AddWithValue("@id",emp.Emp_ID);
                cmd.Parameters.AddWithValue("@name", emp.Emp_Name);
                cmd.Parameters.AddWithValue("@contact", emp.Emp_Contact);
                cmd.Parameters.AddWithValue("@salary", emp.Salary);
                cmd.Parameters.AddWithValue("@did", emp.Did);
                cmd.Connection = con;
                con.Open();
                n = int.Parse(cmd.ExecuteScalar().ToString());
                
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            finally
            {
                con.Close();
            }
            return n;
        }
        public bool Update(Employee emp)
        {
            int n = 0;
            bool IsUpdated = false;
            SqlConnection con = null;
            try
            {
             //   Employee emp = new Employee();
                con = new SqlConnection();
                con.ConnectionString = "Server=.;Initial Catalog=Northwind;User Id=sa;Password=wipro@123";
                SqlCommand cmd = new SqlCommand();
                cmd.CommandText = "update employee set emp_id=@id,emp_name=@name,emp_contact=@contact,@salary=@salary,dept_no=@did where emp_id=@id";
                cmd.Parameters.AddWithValue("@id", emp.Emp_ID);
                cmd.Parameters.AddWithValue("@name", emp.Emp_Name);
                cmd.Parameters.AddWithValue("@contact", emp.Emp_Contact);
                cmd.Parameters.AddWithValue("@salary", emp.Salary);
                cmd.Parameters.AddWithValue("@did", emp.Did);
                cmd.Connection = con;
                con.Open();
                n = cmd.ExecuteNonQuery();
                if(n==1)
                {
                    IsUpdated = true;
                }

            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            finally
            {
                con.Close();
            }
            return IsUpdated;
        }

        public bool Delete(int emp_id)
        {
            int n = 0;
            bool IsDeleted = false;
            SqlConnection con = null;
            try
            {               
                con = new SqlConnection();
                con.ConnectionString = "Server=.;Initial Catalog=Northwind;User Id=sa;Password=wipro@123";
                SqlCommand cmd = new SqlCommand();
                cmd.CommandText = "delete from employee where emp_id=@id";               
                cmd.Parameters.AddWithValue("@id", emp_id);                
                cmd.Connection = con;
                con.Open();
                n = cmd.ExecuteNonQuery();
                if (n == 1)
                {
                    IsDeleted = true;
                }

            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            finally
            {
                con.Close();
            }
            return IsDeleted;
        }
        public Employee search(int emp_id)
        {
            Employee empd = null;
            SqlConnection con = null;
            try
            {
                con = new SqlConnection();
                con.ConnectionString = "Server=.;Initial Catalog=Northwind;User Id=sa;Password=wipro@123";
                SqlCommand cmd = new SqlCommand();
                cmd.CommandText = "select * from employee where emp_id=@id";
                cmd.Parameters.AddWithValue("@id", emp_id);
                cmd.Connection = con;
                con.Open();
                SqlDataReader dr= cmd.ExecuteReader();
                empd = new Employee();
                if(dr.HasRows)
                {
                    while(dr.Read())
                    {
                        empd.Emp_ID = int.Parse(dr["emp_id"].ToString());
                        empd.Emp_Name = dr["emp_name"].ToString();
                    }
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
            finally
            {
                con.Close();
            }
            return empd;
        }

    }
}
