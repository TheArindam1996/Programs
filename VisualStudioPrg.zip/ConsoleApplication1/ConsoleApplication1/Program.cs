﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication1
{
    public class UserMainCode
    {
        public int countPrimesInRange(int input1, int input2)
        {
            //Read only region end
            //Write code here
            Console.WriteLine(input1+" "+input2);
            int count = 0, result = 0;
            for (int i = input1; i <= input2; i++)
            {
                for (int j = 2; j <= input1; j++)
                {
                    if (i % j == 0)
                    {
                        count++;
                    }
                }
                if (count == 1)
                {
                    result = result + 1;
                }
                count = 0;
            }

            return result;
        }

        static void Main()
        {
            UserMainCode umc = new UserMainCode();
            Console.WriteLine(umc.countPrimesInRange(2, 20));
        }
    }
}

