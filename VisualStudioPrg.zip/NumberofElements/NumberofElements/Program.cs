﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NumberofElements
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] intarr = { 20, 20, 4, 40, 56, 222, 12, 0, 4, 7, 8, 22 };
            int count = 0;
            for (int i = 0; i < intarr.Length; i++)
            {
                count++;
            }
            Console.WriteLine("Length of the array is " + count);
        }
    }
}
