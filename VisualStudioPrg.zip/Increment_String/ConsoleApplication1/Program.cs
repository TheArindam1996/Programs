﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


class Program
{
    static void Main(string[] args)
    {
        Console.WriteLine("Enter a String ");
        string str = Console.ReadLine();
        int asi;
        char ch;        
        for (int i = 0; i < str.Length; i++)
        {
            asi = (int)str[i];
            asi++;
            ch = (char)asi;
            Console.Write(ch);
        }
        Console.WriteLine();
    }
}

