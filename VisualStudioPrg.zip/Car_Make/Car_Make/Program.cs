﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Program
{
    class Program
    {
        static void Main(string[] args)
        {
            Car car = new Car("Mercedes Benz","G-Class","2003","2.19 crore");
            car.DisplayCar();
        }
    }
    class Car
    {
        string carmake;
        string model;
        string year;
        string price;
        public Car(string carmake, string model, string year, string price)
        {
            this.carmake = carmake;
            this.model = model;
            this.year = year;
            this.price = price;
        }
       public void DisplayCar()
        {
            Console.WriteLine("Carmake -> "+carmake+" \nModel -> "+model+" \nYear -> "+year+" \nPrice -> "+price);
        }

    }
}
