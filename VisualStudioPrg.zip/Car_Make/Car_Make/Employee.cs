﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Program
{
    class Employee
    {
        string EmployeeName;
        double BasicSalary;
        double HRA;
        double DA;
        double TAX;
        double GrossSalary;
        double NetSalary;
        public Employee(string EmployeeName, double BasicSalary)
        {
            this.EmployeeName = EmployeeName;
            this.BasicSalary = BasicSalary;
        }
        void CalculateNetPay()
        {
            HRA = (15 / 100) * BasicSalary;
            DA = (10 / 100) * BasicSalary;
            GrossSalary = BasicSalary + DA + HRA;
            TAX = (8 / 10) * GrossSalary;
            NetSalary = GrossSalary - TAX;
        }
        void Display()
        {
            Console.WriteLine("Employee Name -> "+EmployeeName+"\n BasicSalary -> "+BasicSalary+"\nHRA -> "+HRA+
                "\n Da -> "+DA+"\nTAX -> "+TAX+"\nGrossSalary -> "+GrossSalary+"\n NetSalary -> "+NetSalary);
        }
        static void Main()
        {
            Employee employee = new Employee("Adam",30000.65);
            employee.CalculateNetPay();
            employee.Display();
        }
    }
}
