﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace String_specific
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("enter a string");
            string str = Console.ReadLine();
            for(int i =1;i<str.Length;i++)
                {
                Console.Write(str[i]);
            }
            Console.WriteLine();
        }
    }
}
