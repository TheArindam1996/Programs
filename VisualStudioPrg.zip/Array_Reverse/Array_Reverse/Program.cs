﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Array_Reverse
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter an array");
            int[] arr = new int[10];
            for(int i=0;i<arr.Length;i++)
            {
                arr[i] = Convert.ToInt32(Console.ReadLine());
            //    Console.Write(arr[i]);
            }
            Array.Reverse(arr);
            foreach(int i in arr)
            {
                Console.Write(i+" ");
            }
            Console.WriteLine();
        }
    }
}
