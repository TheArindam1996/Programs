﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Swap_Values
{
    class Program
    {
        static void Main(string[] args)
        {
            
            Console.WriteLine("Enter two numbers");
            int a = Convert.ToInt32(Console.ReadLine());
            int b = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Before swaping "+a + " " + b);
            a = a + b;
            b = a - b;
            a = a - b;

            Console.WriteLine("After swaping "+a+ " " + b);
        }
    }
}
