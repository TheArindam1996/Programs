﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lower_upper
{
    class Program
    {
        static void Main(string[] args)
        {
            string str = Console.ReadLine();
            string st = "";
            for (int k = 0; k < str.Length; k++)
            {
                int j = (int)str[k];
                if (j >= 65 || j <= 90)
                    st = st + char.ToLower(str[k]);

                else if (j >= 97 || j <= 122)
                    st = st + char.ToUpper(str[k]);
            }

            Console.WriteLine(st);
        }
    }
}
