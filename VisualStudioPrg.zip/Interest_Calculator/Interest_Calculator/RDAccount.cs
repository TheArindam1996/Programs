﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Interest_Calculator
{
    class RDAccount:IAccount
    {
        double Interest_rate;
        double Amount;
        int No_of_days;
        int Age;
        public double CalculateInterest()
        {
            Console.WriteLine("Enter the amount");
            Amount = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("Enter the no of days");
            No_of_days = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter the no of days");
            Age = Convert.ToInt32(Console.ReadLine());
            if (No_of_days<=180 && Age<60)
            {
                Interest_rate = (7.5 / 100) * Amount;
            }
            else if(No_of_days <= 180 && Age > 60)
                Interest_rate = (8.0 / 100) * Amount;
            else if(No_of_days>180&&No_of_days<=270 && Age>60)
                Interest_rate = (7.75 / 100) * Amount;
            else if(No_of_days > 180 && No_of_days <= 270 && Age < 60)
                Interest_rate = (8.25 / 100) * Amount;
            else if (No_of_days > 271 && No_of_days <= 360 && Age > 60)
                Interest_rate = (8.0 / 100) * Amount;
            else if (No_of_days > 271 && No_of_days <= 360 && Age < 60)
                Interest_rate = (8.5 / 100) * Amount;
            else if (No_of_days > 361 && No_of_days <= 450 && Age < 60)
                Interest_rate = (8.25 / 100) * Amount;
            else if (No_of_days > 361 && No_of_days <= 450 && Age > 60)
                Interest_rate = (8.75 / 100) * Amount;
            else if (No_of_days > 451 && No_of_days <= 540 && Age < 60)
                Interest_rate = (8.5 / 100) * Amount;
            else if (No_of_days > 451 && No_of_days <= 540 && Age > 60)
                Interest_rate = (9.0 / 100) * Amount;
            else if (No_of_days > 541 && No_of_days <= 630 && Age > 60)
                Interest_rate = (8.75 / 100) * Amount;
            else if (No_of_days > 541 && No_of_days <= 630 && Age > 60)
                Interest_rate = (9.25 / 100) * Amount;

            return Interest_rate;
        }
     }
}

