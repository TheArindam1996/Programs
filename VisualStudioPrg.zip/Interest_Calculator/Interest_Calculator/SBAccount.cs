﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Interest_Calculator
{
    class SBAccount:IAccount
    {
        double Interest_rate;
        double Amount;
        public double CalculateInterest()
        {
            Console.WriteLine("Enter the Average amount in your account");
            Amount = Convert.ToDouble(Console.ReadLine());
            Interest_rate = (4.0 / 100) * Amount;
            return Interest_rate;
        }
    }
}
