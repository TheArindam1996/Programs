﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Interest_Calculator
{
    class Call
    {
        static void Main()
        {
            bool check = true;
            while (check)
            {
                Console.WriteLine("1. Interest Calculator - SB ");
                Console.WriteLine("2. Interest Calculator - FD ");
                Console.WriteLine("3. Interest Calculator - RD ");
                Console.WriteLine("4. exit");
                int n = Convert.ToInt32(Console.ReadLine());
                switch (n)
                {
                    case 1: SBAccount sb = new SBAccount();
                            Console.WriteLine(sb.CalculateInterest());
                            break;

                    case 2: FDAccount fd = new FDAccount();
                            Console.WriteLine(fd.CalculateInterest());
                            break;

                    case 3: RDAccount rd = new RDAccount();
                            Console.WriteLine(rd.CalculateInterest());
                            break;
                        
                    case 4: check =false;
                            break;
                }
            }
            
        }
    }
}
