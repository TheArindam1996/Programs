﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Interest_Calculator
{
    class FDAccount:IAccount
    {
        double Interest_Rate;
        double Amount;
        int No_of_days;
        int Age;
        public double CalculateInterest()
        {
            Console.WriteLine("Enter the FD amount");
            Amount = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("Enter the number of days");
            No_of_days = Convert.ToInt32(Console.ReadLine());            
            if(Amount<10000000)
            {
                Console.WriteLine("Enter your age");
                Age = Convert.ToInt32(Console.ReadLine());        

                if (No_of_days >= 7 && No_of_days <= 14 && Age > 60)
                            Interest_Rate = (5.0 / 100) * Amount;
                            else if(No_of_days >= 7 && No_of_days <= 14 && Age < 60)
                            Interest_Rate = (4.5 / 100) * Amount;
                            

                    if (No_of_days >= 15 && No_of_days <= 29 && Age > 60)
                            Interest_Rate = (5.25 / 100) * Amount;
                            else if (No_of_days >= 15 && No_of_days <= 29 && Age < 60)                            
                            Interest_Rate = (4.75 / 100) * Amount;
                            

                     if (No_of_days >= 30 && No_of_days <= 45 && Age > 60)
                            Interest_Rate = (6.0 / 100) * Amount;
                            else if (No_of_days >= 30 && No_of_days <= 45 && Age < 60)
                            Interest_Rate = (5.5 / 100) * Amount;
                            

                     if (No_of_days >= 45 && No_of_days <= 60 && Age > 60)
                            Interest_Rate = (7.5 / 100) * Amount;
                            else if (No_of_days >= 7 && No_of_days <= 14 && Age < 60)
                            Interest_Rate = (7 / 100) * Amount;
                            

                     if (No_of_days >= 61 && No_of_days <= 184 && Age > 60)
                            Interest_Rate = (8.0 / 100) * Amount;
                            else if (No_of_days >= 61 && No_of_days <= 184 && Age < 60)
                            Interest_Rate = (7.5 / 100) * Amount;
                            

                     if (No_of_days >= 185 && No_of_days <= 365 && Age > 60)
                            Interest_Rate = (8.5 / 100) * Amount;
                            else if (No_of_days >= 185 && No_of_days <= 365 && Age < 60)
                            Interest_Rate = (8.0 / 100) * Amount;         
            }
            else if(Amount>10000000)
            {
                
                
                    if (No_of_days >= 7 && No_of_days <= 14)
                            Interest_Rate = (6.5 / 100) * Amount;                        
                            

                    if (No_of_days >= 15 && No_of_days <= 29)
                            Interest_Rate = (6.75 / 100) * Amount;                        
                           

                  if (No_of_days >= 30 && No_of_days <= 45)
                            Interest_Rate = (6.75 / 100) * Amount;                        
                         

                   if (No_of_days >= 45 && No_of_days <= 60)
                            Interest_Rate = (8.0 / 100) * Amount;                        
                            
                    if (No_of_days >= 61 && No_of_days <= 184)
                            Interest_Rate = (8.5 / 100) * Amount;                        
                            

                     if (No_of_days >= 185 && No_of_days <= 365)
                            Interest_Rate = (10.0 / 100) * Amount;     
                            
                }
            return Interest_Rate;
            }
           
        }
    }

