﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Inheritance_Example1
{
    class Person
    {
        private string FirstName;
        private string LastName;
        private string EmailAddress;
        private string DateofBirth;
        private DateTime Date1;
        public bool IsAdult()
        {
            int year = Date1.Year;
            
            if ((2018-year) < 18)
            {
                return false;
            }
            else if ((2018 - year) > 18)
            {
                return true;
            }

            else
                return false;
        }
        public bool IsBirthDay()
        {
            int month = Date1.Month;
            int m = Date1.Day;
            DateTime d = DateTime.Now;
            int month1 = d.Month;
            int day1 = d.Day;
            if (month == month1 && m == day1)
            {
                return true;
            }
            else
                return false;                
        }
       public void Display()
        {
            Console.WriteLine(FirstName+" "+LastName);
        }
        public Person(string FirstName, string LastName, string EmailAddress, string DateofBirth)
        {
            this.FirstName = FirstName;
            this.LastName = LastName;
            this.EmailAddress = EmailAddress;
            this.DateofBirth = DateofBirth;
            Date1 = DateTime.Parse(DateofBirth);

        }
     /*   static void Main(string[] args)
        {
          
        }
        */
    public string SunSine()
        {
            int day = Date1.Day;
            int month = Date1.Month;
            if (month == 1 || month == 2)
            {
                if (day <= 20 || day >= 31 && day <= 1 || day >= 18)
                {
                    return "Aquarius";

                }
            }
            if (month == 2 || month == 3)
            {
                if(day <= 19 || day >= 28 && day <= 1 || day >= 20)
                {
                    return "Pices";
                }
            }
            if (month == 3 || month == 4)
            {
                if (day <= 21 || day >= 32 && day <= 1 || day >= 19)
                {
                    return "Aries";
                }
            }
            if (month == 4 || month == 5)
            {
                if (day <= 20 || day >= 30 && day <= 1 || day >= 20)
                {
                    return "Taurus";
                }
            }
            if (month == 5 || month == 6)
            {
                if (day <= 21 || day >= 31 && day <= 1 || day >= 20)
                {
                    return "Gemini";
                }
            }
            if (month == 6 || month == 7)
            {
                if (day <= 21 || day >= 30 && day <= 1 || day >= 22)
                {
                    return "Cancer";
                }
            }
            if (month == 7 || month == 8)
            {
                if (day <= 23 || day >= 31 && day <= 1 || day >= 22)
                {
                    return "Leo";
                }
            }
            if (month == 8 || month == 9)
            {
                if (day <= 23 || day >= 31 && day <= 1 || day >= 22)
                {
                    return "Virgo";
                }
            }
            if (month == 9 || month == 10)
            {
                if (day <= 23 || day >= 30 && day <= 1 || day >= 22)
                {
                    return "Libra";
                }
            }
            if (month == 10 || month == 11)
            {
                if (day <= 23 || day >= 31 && day <= 1 || day >= 21)
                {
                    return "Scorpio";
                }
            }
            if (month == 11 || month == 12)
            {
                if (day <= 22 || day >= 30 && day <= 1 || day >= 2)
                {
                    return "Sagittarius";
                }
            }
            if (month == 12 || month == 1)
            {
                if (day <= 22 || day >= 30 && day <= 1 || day >= 19)
                {
                    return "Sagittarius";
                }
            }
            return "";
        }
    }
    class Employee : Person
    {
        
        public Employee(string FirstName, string LastName, string EmailAddress, string DateofBirth) : base(FirstName, LastName, EmailAddress, DateofBirth)
        {
        }
        static void Main(string[] args)
        {
            string date1 = Console.ReadLine();
            Person p = new Person("Max"," Richards\n","maxrichards12@xyz.com\n",date1);
            p.Display();
            Console.WriteLine(p.IsAdult());
            Console.WriteLine(p.IsBirthDay());
            Console.WriteLine(p.SunSine());
        }
    }
}
