﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication3
{
    class Program
    {
      static void Main()
      {
            Console.WriteLine("enter a sting");
            string str = Console.ReadLine();
            List<char> alphalist = new List<char>();
            List<int> digitlist = new List<int>();           
            for(int j=0;j<str.Length;j++)
            {
                 char ch = str.ElementAt(j);
                    if (Char.IsDigit(ch))
                        digitlist.Add((int)char.GetNumericValue(ch));
                    else if(Char.IsLetter(ch))
                        alphalist.Add(ch);
            }
            alphalist.Sort();
            digitlist.Sort();
            Console.WriteLine("AlphaList");
            for(int i=0;i<alphalist.Count;i++)
            {
                Console.Write(alphalist.ElementAt(i));

            }
            Console.WriteLine();
            Console.WriteLine("DigitList");
            for (int i = 0; i < alphalist.Count; i++)
            {
                Console.Write(digitlist.ElementAt(i));

            }
            Console.WriteLine();
        }

    }
}
