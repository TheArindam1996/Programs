﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MiniProject
{
    class Program
    {
        static void Main(string[] args)
        {
            int T = Convert.ToInt32(Console.ReadLine());
            char[] manipulate = new char[20];
            string[] str = new string[T];
            int m, n, length = 0;
            char temp;
            for (int k = 0; k < T; k++)
            {
                str[k] = Console.ReadLine();

            }
            for (int i = 0; i < T; i++)
            {
                manipulate = str[i].ToCharArray();
                length = manipulate.Length;
                m = (int)Char.GetNumericValue(manipulate[manipulate.Length - 1]);
                n = (int)Char.GetNumericValue(manipulate[manipulate.Length - 3]);
              //  Console.WriteLine(m+" "+n);
                for (int j = n; j <m; j++)
                {
                    int ch = (int)manipulate[j];
                    for (int x = j + 1; x <= m; x++)
                    {
                        if (ch <(int)manipulate[x])
                        {
                            temp = manipulate[j];
                            manipulate[j] = manipulate[x];
                            manipulate[x] = temp;
                        }
                       

                    }

                }

                for (int d = 0; d < length - 4; d++)
                {
                    Console.Write(manipulate[d]);
                }
                Console.WriteLine();
                
            }


        }

    }
}
