﻿using System;
    class Program
    {
         public static void Main(string[] ag)
        {
            int side = 0;
            Console.WriteLine("Enter the side of square");
            side = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("The area of square is " + (side * side));
            Console.ReadKey();

        }
    }

    