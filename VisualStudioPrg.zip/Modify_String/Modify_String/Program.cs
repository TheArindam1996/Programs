﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Modify_String
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Write a string");
            string str = Console.ReadLine();
            string str1 = str;
            str1=str1.Replace(str1[2], '@');
            Console.WriteLine(str+" "+str1);
        }
    }
}
