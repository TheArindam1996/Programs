﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication2
{
    class Program
    {
        static void Main(string[] args)
        {
            int n = 0,n1=0,count=0;
            n = Convert.ToInt32(Console.ReadLine());
            n1 = Convert.ToInt32(Console.ReadLine());
            for (int i=n;i<=n1;i++)
            {
                for(int j=2;j<=n1;j++)
                {
                    if (i % j == 0)
                        count++;
                }
                if(count==1)
                {
                    Console.Write(i+" ");                    
                }
                count = 0;
            }
            //if (count == 1)
            //    Console.WriteLine("prime");
            //else
            //    Console.WriteLine("Not prime");
            Console.WriteLine();
        }
    }
}
