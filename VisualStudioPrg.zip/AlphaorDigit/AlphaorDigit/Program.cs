﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Alpha_or_Digit
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter a character ");
            char ch = Convert.ToChar(Console.ReadLine());
            int a = (int)ch;
            if (a >= 65 && a <= 90 || a >= 97 && a <= 122)
            {
                Console.WriteLine("It is a character ");
            }
            else if (a >= 48 || a <= 57) {
                Console.WriteLine("It is a digit ");
            }
                

        }
    }
}
