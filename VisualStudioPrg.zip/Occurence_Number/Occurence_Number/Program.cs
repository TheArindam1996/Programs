﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Occurence_Number
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter two number");
            int num1 = Convert.ToInt32(Console.ReadLine()), count = 0,temp=0;
            int num2 = Convert.ToInt32(Console.ReadLine());
            while(num1>0)
            {
                temp = num1 % 10;
                if (temp == num2)
                    count++;
                num1 = num1 / 10;
            }
            if (count == 0)
                Console.WriteLine("Number is not present");
            else
                Console.WriteLine(count);
        }
    }
}
