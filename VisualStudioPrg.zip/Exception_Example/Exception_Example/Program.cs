﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exception_Example
{
    class Program
    {
        static int Math;
        static int English;
        static int History;
        static void Main(string[] args)
        {
            Console.WriteLine("Enter the name of student");
            string name = Console.ReadLine();
            try
            {
                Math = Convert.ToInt32(Console.ReadLine());
              //  English = Convert.ToInt32(Console.ReadLine());
               // History = Convert.ToInt32(Console.ReadLine());
                if(Math<0||English<0||History<0)
                {
                    throw new NegativeNumberException("Enter a positive number");
                }
            }
            catch (NegativeNumberException e) {
                Console.WriteLine(e.Message);
            }
        }
    }

    class NegativeNumberException : Exception
    {
        public NegativeNumberException(String message) : base(message)
        {

        }
    }
}
