﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exception_Example
{
    class Demo
    {
        int m;
        int n;
        int z;
        public Demo(int m,int n,int z)
        {
            this.m = m;
            this.n = n;
            this.z = z;
        }
    }

    class Demo1 : Demo
    {
        public Demo1(int m,int n,int z,int q):base(m,n,z)
        {

        }
    }
}
