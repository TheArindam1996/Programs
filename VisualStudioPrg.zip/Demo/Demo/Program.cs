﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


class Program
{
    static public string foo(int input)
    {
        if (input > 2)
            return "palindrome;";
        else
            return "";
    }
    static void Main(string[] a)
    {
        
        Console.WriteLine(foo(int.Parse(Console.ReadLine())));
    }
}
    
    


