﻿using System;

using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RandomHelper
{
    class Program
    {
        public static int randomInt(int x, int y)
        {
            Random random = new Random();
            int result = random.Next(x,y);
            return result;
        }
        public static double RandomDouble(int x,int y)
        {
              Random random = new Random();
            int result = random.Next(x, y);
            double result1 = result* random.NextDouble();           
            return result1;
        }
    }

    class Call
    {
        static void Main()
        {
            Console.WriteLine(Program.randomInt(1,10)+" "+Program.RandomDouble(1,10));
        }
    }
}
