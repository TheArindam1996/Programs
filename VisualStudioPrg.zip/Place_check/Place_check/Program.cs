﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Place_check
{
    class Program
    {
        static void Main(string[] args)
        {
            string a= (Console.ReadLine());
            char b= Convert.ToChar(Console.ReadLine());
            for(int i=0;i<a.Length;i++)
            {
                if (a[i] == b)
                    Console.WriteLine("Position "+i);
            }
        }
    }
}
