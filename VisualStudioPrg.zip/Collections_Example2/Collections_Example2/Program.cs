﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Collections_Example2
{
    class Employee
    {
        string EmpName;
        int EmpId;
        double Salary;
        public string EmpNe { get; set; }
        public int EmpID { get; set; }
        public double EmpSalary { get; set; }

    }
}
