﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;
namespace Collections_Example2
{
    class EmployeeDAL
    {
        SortedList sl = new SortedList();
        static Employee emp;
        public bool AddEmployee(Employee e)
        {
            sl.Add(e.EmpID,e);
            if (sl.Count > 0)
                return true;
            else
                return false;
        }
        public bool DeleteEmployee(int id)
        {
            for (int i = 0; i < sl.Count; i++)
            {
                Employee ep = sl.GetByIndex(i) as Employee;
                if (ep.EmpID == id)
                    break;

                else if (i == sl.Count - 1)
                    return false;
            }
            sl.RemoveAt((int)sl.GetKey(id));
            return true;
        }
        public string SearchEmployee(int id)
        {
            string empname = "";
            for (int i = 0; i < sl.Count; i++)
            {
               // Employee ep = sl[i] as Employee;
                if ((int)sl.GetKey(i) == id)
                    empname = emp.EmpNe ;

                else
                    empname = "Employee does not found";
            }
            return empname;
        }
        public Employee[] GetEmployeeListAll()
        {
            Employee[] emp = new Employee[sl.Count];
            int i = 0;
            for(i=0;i<sl.Count;i++)
            {
                emp[i] = sl.GetByIndex(i) as Employee;
            }
            return emp;
        }
        static void Main(string[] args)
        {
            bool infy = true;

            EmployeeDAL edal = new EmployeeDAL();
            int val = 0;
            while (infy)
            {
                Console.WriteLine("\n1. Add Employee");
                Console.WriteLine("2. Delete Employee");
                Console.WriteLine("3. Search Employee");
                Console.WriteLine("4. Get list of all employees");
                Console.WriteLine("5. Exit\n");
                val = int.Parse(Console.ReadLine());

                switch (val)
                {
                    case 1:
                        emp = new Employee();
                        Console.WriteLine("Enter employee id");
                        emp.EmpID = int.Parse(Console.ReadLine());
                        Console.WriteLine("Enter employee name");
                        emp.EmpNe = Console.ReadLine();
                        Console.WriteLine("Enter employee salary");
                        emp.EmpSalary = double.Parse(Console.ReadLine());
                        if (edal.AddEmployee(emp) == true)
                            Console.WriteLine("Employee Added Successfully\n");
                        break;

                    case 2:
                        Console.WriteLine("Enter the employee id to be deleted");
                        if (edal.DeleteEmployee(int.Parse(Console.ReadLine())) == true)
                            Console.WriteLine("Record Deleted\n");
                        else
                            Console.WriteLine("Record does not exist as per the given id\n");
                        break;

                    case 3:
                        Console.WriteLine("Enter the employee id to be searched");
                        Console.WriteLine(edal.SearchEmployee(int.Parse(Console.ReadLine())) + "\n");
                        break;

                    case 4:
                        Employee[] p = edal.GetEmployeeListAll();
                        for (int i = 0; i < p.Length; i++)
                        {
                            Console.Write(p[i].EmpID + " " + p[i].EmpNe + " " + p[i].EmpSalary + "\n");
                        }
                        
                        break;

                    case 5:
                        infy = false;
                        break;
                        
                    default:    Console.WriteLine("Bad input");
                                break;


                }
            }
        }
    }
}
