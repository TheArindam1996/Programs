﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Program
{
    class Employee
    {
        string EmployeeName;
        double BasicSalary;
        double HRA;
        double DA;
        double TAX;
        double GrossSalary;
        double NetSalary;
        public Employee(string EmployeeName, double BasicSalary)
        {
            this.EmployeeName = EmployeeName;
            this.BasicSalary = BasicSalary;
        }
       public void CalculateNetPay()
        {
            double interest = 10.0 / 100.0;
            HRA = interest * BasicSalary;
            this.DA = (15.0/100.0) * BasicSalary;
            this.GrossSalary = BasicSalary + DA + HRA;
            this.TAX = (8.0/100.0) * GrossSalary;
            this.NetSalary = GrossSalary - TAX;
           
        }
        void Display()
        {
            Console.WriteLine("Employee Name -> " + EmployeeName + "\n BasicSalary -> " + BasicSalary + "\nHRA -> " + HRA +
                "\n DA -> " + DA + "\nTAX -> " + TAX + "\nGrossSalary -> " + GrossSalary + "\n NetSalary -> " + NetSalary);
        }
        
        static void Main(string[] args)
        {
            Employee employee = new Employee("Adam", 30000);
            employee.CalculateNetPay();
            employee.Display();
        }
    }
}
