﻿using System;

public class Class1
{
     static void Main(string[] args)
    {
        Console.WriteLine("Enter a string");
        string str = Console.ReadLine();
        int count = 0;
        for (char a = 'a'; a <= 'z'; a++)
        {
            for (int i = 0; i < str.Length; i++)
            {
                if (str[i] == a)
                    count++;
            }
        }
        Console.WriteLine("Number of alphabets in the string are " + count);
        count = 0;
        for (char j = '1'; j <= '9'; j++)
        {
            for (int i = 0; i < str.Length; i++)
            {
                if (str[i] == j)
                    count++;
            }
        }
        Console.WriteLine("Numbers in the string are " + count);

    }
}
