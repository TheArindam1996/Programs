﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;
namespace Collections_Example
{
    class Palindrome_Possible
    {
        static void Main()
        {
            ArrayList arr = new ArrayList();
            arr.Add(1);
            arr.Add(2);
            arr.Add(3);
            arr.Add(4);
            Console.WriteLine(arr.Count);
        }
    }
}
