﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Person_Details
{
    class Person
    {
        public string FirstName;
        public string LastName;
        public string Email_Address;
        DateTime date;
        int Year, day,month;
        public Person(string FirstName,string LastName,string Email_Address, string Date_of_Birth)
        {
            this.FirstName = FirstName;
            this.LastName = LastName;
            this.Email_Address = Email_Address;
            date = Convert.ToDateTime(Date_of_Birth);
            Year = date.Year;
            day = date.Day;
            month = date.Month;
        }
        public bool IsAdult
        {
            
            get
            {
                bool check = true;
                DateTime dt = DateTime.Now;
                int day = dt.Day;
                if(2018-Year>=18 && this.day-day>=0)
                {
                    check= true;
                }
                else
                {
                    check = false;
                }
                return check;
            }
        }
        public string SunSign
        {
            get
            {
                string sunsign = "";
                if (month == 1 || month == 2)
                {
                    if (day <= 20 || day >= 31 && day <= 1 || day >= 18)
                    {
                        sunsign = "Aquarius";

                    }
                }
                if (month == 2 || month == 3)
                {
                    if (day <= 19 || day >= 28 && day <= 1 || day >= 20)
                    {
                        sunsign = "Pices";
                    }
                }
                if (month == 3 || month == 4)
                {
                    if (day <= 21 || day >= 32 && day <= 1 || day >= 19)
                    {
                        sunsign = "Aries";
                    }
                }
                if (month == 4 || month == 5)
                {
                    if (day <= 20 || day >= 30 && day <= 1 || day >= 20)
                    {
                        sunsign = "Taurus";
                    }
                }
                if (month == 5 || month == 6)
                {
                    if (day <= 21 || day >= 31 && day <= 1 || day >= 20)
                    {
                        sunsign = "Gemini";
                    }
                }
                if (month == 6 || month == 7)
                {
                    if (day <= 21 || day >= 30 && day <= 1 || day >= 22)
                    {
                        sunsign = "Cancer";
                    }
                }
                if (month == 7 || month == 8)
                {
                    if (day <= 23 || day >= 31 && day <= 1 || day >= 22)
                    {
                        sunsign = "Leo";
                    }
                }
                if (month == 8 || month == 9)
                {
                    if (day <= 23 || day >= 31 && day <= 1 || day >= 22)
                    {
                        sunsign = "Virgo";
                    }
                }
                if (month == 9 || month == 10)
                {
                    if (day <= 23 || day >= 30 && day <= 1 || day >= 22)
                    {
                        sunsign = "Libra";
                    }
                }
                if (month == 10 || month == 11)
                {
                    if (day <= 23 || day >= 31 && day <= 1 || day >= 21)
                    {
                        sunsign = "Scorpio";
                    }
                }
                if (month == 11 || month == 12)
                {
                    if (day <= 22 || day >= 30 && day <= 1 || day >= 2)
                    {
                        sunsign = "Sagittarius";
                    }
                }
                if (month == 12 || month == 1)
                {
                    if (day <= 22 || day >= 30 && day <= 1 || day >= 19)
                    {
                        sunsign = "Sagittarius";
                    }
                }
                return sunsign;
            }
        }
        public string IsBirthday
        {
            get
            {
                string dob = "yes";
                DateTime dt = DateTime.Now;
                int day = dt.Day;
                int month = dt.Month;
                if (this.month == month && this.day == day)
                    dob = "yes";
                else
                    dob = "no";
                return dob;
            }
        }
       /* static void Main(string[] args)
        {

        }
        */
    }

}
