﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Person_Details
{
    class Employee:Person
    {
        static double salary;
        Employee(string FirstName,string LastName, string email, string Dob):base(FirstName,LastName,email,Dob)
        {

        }
        static void Main()
        {
            Console.WriteLine("Enter the details");
            string m = Console.ReadLine();
            string n = Console.ReadLine();
            string n1 = Console.ReadLine();
            string n2 = Console.ReadLine();
            salary = Convert.ToDouble(Console.ReadLine());
            Person p = new Person(m,n,n1,n2);
            Console.WriteLine(p.FirstName);
            Console.WriteLine(p.LastName);
            Console.WriteLine(p.Email_Address);
            Console.WriteLine(p.IsAdult);
            Console.WriteLine(p.IsBirthday);
            Console.WriteLine(p.SunSign);
            Console.WriteLine(salary);
        }
    }
}
