﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Stock
{
    class Program
    {
        string StockName;
        string StockSymbol;
        double PreviousClosingPrice;
        double CurrentClosingPrice;
        static void Main(string[] args)
        {
            Program stock = new Program("Axis Bank Ltd.","$",619.65,600.34);
            double percentagechange=stock.getPercentageChange();
            Console.WriteLine(percentagechange);
        }
        public Program(string StockName, string StockSymbol, double PreviousClosingPrice, double CurrentClosingPrice)
        {
            this.StockName = StockName;
            this.StockSymbol = StockName;
            this.PreviousClosingPrice = PreviousClosingPrice;
            this.CurrentClosingPrice = CurrentClosingPrice;
        }
        double getPercentageChange()
        {
            double result = 0;
            result = ((PreviousClosingPrice - CurrentClosingPrice) / CurrentClosingPrice)*100;
            return result;
        }
    }
}
