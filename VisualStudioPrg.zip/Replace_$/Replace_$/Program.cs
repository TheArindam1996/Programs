﻿using System;
namespace Replace__
{
    class Program
    {
        static void Main(string[] args)
        {
            int i = 0;
            Console.WriteLine("Enter a string");
            string s = Console.ReadLine();
            
            string str = "";
            char ch = Convert.ToChar(Console.ReadLine());
            Console.WriteLine("Enter the character to replace");       
            s= s.Replace(ch,'$');               
            Console.WriteLine(s);
        }
    }
}
