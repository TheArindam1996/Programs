﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CharacterCount
{
    class Program
    {
        static void Main(string[] args)
        {
            string str = Console.ReadLine();            
            char[] c1 = str.ToCharArray();
            string s1 = "";
            string s2 = "";
            int count = 0,j=0,i=0,k=0;
            for(char a='a';a<='z';a++)
            {
                for(i=0;i<str.Length;i++)
                {
                    if (a == c1[i])
                        count++;
                }
                if (count > 0)
                {
                    //Console.Write(a + " -> " + count + " ");
                    s1 = s1 + a;
                    s2 = s2 + count;
                    count = 0;
                }               
            }
            char[] ch1 = s1.ToCharArray();
            char[] ch2 = s2.ToCharArray();
            for(i=0;i<c1.Length;i++)
            {
                //char cg = ch1[i];
                for(j=0;j<ch1.Length;j++)
                {
                    if(c1[i]==ch1[j])
                    {            
                          Console.Write(c1[i] + " -> " + ch2[j] + "\n");                            
                            break;             
                    }
                    //k = 0;
                }
                
            }
            
         //   Console.WriteLine(s1+" "+s2);
        }
    }
}
