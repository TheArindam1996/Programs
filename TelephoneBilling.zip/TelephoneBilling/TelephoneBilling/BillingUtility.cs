﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TelephoneBilling.Utility
{
    public class BillingUtility
    {
        decimal Charge_Per_Unit = 0.0m, BillAbleAmount = 0.0m;
        int FixedCharge = 200;
        decimal TotalAmount = 0.0m;
        public decimal CalculateBill(int intNumberOfUnits, decimal decOutstandingAmount = 0.0m)
        {
            if (intNumberOfUnits >= 0 && intNumberOfUnits <= 250)
                Charge_Per_Unit = 1.50m;

            if (intNumberOfUnits >= 251 && intNumberOfUnits <= 500)
                Charge_Per_Unit = 2.50m;

            if (intNumberOfUnits >= 501)
                Charge_Per_Unit = 4.00m;

            BillAbleAmount = intNumberOfUnits * Charge_Per_Unit;
            TotalAmount = BillAbleAmount + FixedCharge + decOutstandingAmount;

            return TotalAmount;

        }
    }
}
