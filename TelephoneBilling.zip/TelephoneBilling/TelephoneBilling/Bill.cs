﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TelephoneBilling
{
    public class Bill
    {
        public int BillingID { get; set; }
        public string PhoneNumber { get; set; }
        public DateTime BillingDate { get; set; }
        public int Units { get; set; }
        public decimal OutstandingAmount { get; set; }
        public decimal TotalAmount { get; set; }

        public Bill()
        {

        }
        public Bill(int BillingID, string PhoneNumber,DateTime BillingDate, int Units, decimal OutstandingAmount, decimal TotalAmount)
        {
            this.BillingID = BillingID;
            this.PhoneNumber = PhoneNumber;
            this.BillingDate = BillingDate;
            this.Units = Units;
            this.OutstandingAmount = OutstandingAmount;
            this.TotalAmount = TotalAmount;
        }
    }
}
