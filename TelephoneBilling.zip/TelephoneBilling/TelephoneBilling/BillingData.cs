﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TelephoneBilling.Utility;
using TelephoneBilling.Exceptions;
namespace TelephoneBilling
{
    public class BillingData
    {
        List<Bill> bills = new List<Bill>();        
        BillingUtility billUtil;
        public BillingData()
        {
            
        }

        public bool GenerateBill(Bill obj)
        {
            int random1 = 0;
            bool IsBillGenerated = false;
            if(obj==null)
            {
                IsBillGenerated = false;
            }
            else if (obj != null)
            {
                Random random = new Random();
                random1=random.Next();
                obj.BillingID = random1;
                 billUtil= new BillingUtility();
                if (obj.Units < 0)
                {
                    try
                    {
                        throw new InvalidUnitsException("Invalid units.");
                    }catch(Exception ex)
                    {
                        throw ex;
                    }
                }
                else if(obj.Units >= 0)
                {
                    obj.TotalAmount = billUtil.CalculateBill(obj.Units, obj.OutstandingAmount);
                    bills.Add(obj);
                    IsBillGenerated = true;
                }
                
            }

            return IsBillGenerated;
        }

        public Bill SearchBill(int intBillingID)
        {
            Bill IsFound = null;
            if (intBillingID <= 0)
                IsFound = null;

            else
            {
                for(int i=0;i<bills.Count;i++)
                {
                    if (intBillingID == bills[i].BillingID)
                    {
                        IsFound = bills[i];
                        break;
                    }
                    else
                    {
                        IsFound = null;
                    }
                        
                }
            }
            return IsFound;
        }

        public bool UpdateBill(Bill obj)
        {
            bool IsUpdated=false;
            if(obj==null)
            {
                IsUpdated = false;
            }
            else
            {
                for(int i=0;i<bills.Count;i++)
                {
                    if(bills[i].BillingID==obj.BillingID)
                    {
                        obj.TotalAmount=billUtil.CalculateBill(obj.Units,obj.OutstandingAmount);
                        obj.BillingDate = DateTime.Now;
                        bills[i] = obj;
                        IsUpdated = true;
                    }
                }
            }
            return IsUpdated;
        }
        public List<Bill> GetAllUsers()
        {
            return bills;
        }
    }
}
