﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TelephoneBilling;
namespace TelephoneBilling
{
    class Program
    {
        static void Main(string[] args)
        {
            Bill bill = new TelephoneBilling.Bill();
            BillingData billData = new BillingData();
            billData.GenerateBill(bill);
        }
    }
}
