﻿using System;


namespace VoterEntry.Exceptions
{
    public class AgeException:Exception
    {
        public AgeException(string strMessage):base(strMessage)
        {
            
        }
    }


}
