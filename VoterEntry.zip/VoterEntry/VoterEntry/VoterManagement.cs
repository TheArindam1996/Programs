﻿using System;
using System.Collections.Generic;
using VoterEntry.Utility;
    using VoterEntry.Exceptions;
namespace VoterEntry

{
    public class VoterManagement
    {
        // TODO: Write your code here
        List<Voter> VoterList = new List<Voter>();
        public VoterManagement()
        {
            
            
        }

        public string AddVoter(Voter obj)
        {
            obj.Age = DateTime.Now.Subtract(obj.DateofBirth).Days/365;
            string check="";
          //  Console.WriteLine(obj.VoterID);
          //  if (obj == null)
            //    return null;

            if (!(String.IsNullOrEmpty(obj.FirstName) || String.IsNullOrEmpty(obj.LastName) || String.IsNullOrEmpty(obj.DateofBirth.ToString()) || String.IsNullOrEmpty(obj.FathersName) ||
        String.IsNullOrEmpty(obj.Gender) || String.IsNullOrEmpty(obj.Address) || String.IsNullOrEmpty(obj.ConstituencyName)))
            {
                check= null;
            }
            else
            {
                try{
                    if (obj.Age < 18)
                    {

                        throw new AgeException("Age shouldn’t be less than 18");

                    }
                    else if (obj.Age >= 18)
                    {
                        VoterList.Add(obj);
                        check= obj.VoterID;
                        
                    }
                }
                catch (AgeException exe)
                {
                    throw exe;
                }
                catch (Exception exe1)
                {
                    Console.WriteLine(exe1.Message);
                }

            }

            return check;

        }

        public bool ModifyVoter(Voter obj)
        {
            obj.Age = DateTime.Now.Subtract(obj.DateofBirth).Days/365;
            bool ISUpdated = false;
//if (obj == null)
  //              return false;

                    if(!(String.IsNullOrEmpty(obj.FirstName)|| String.IsNullOrEmpty(obj.LastName)||String.IsNullOrEmpty(obj.DateofBirth.ToString())|| String.IsNullOrEmpty(obj.FathersName)||
                String.IsNullOrEmpty(obj.Gender)|| String.IsNullOrEmpty(obj.Address)|| String.IsNullOrEmpty(obj.ConstituencyName)))
            {
                ISUpdated = false;
            }
            else
            {
                
                    for (int i = 0; i < VoterList.Count; i++)
                    {
                    try
                    {
                        if (VoterList[i].VoterID == obj.VoterID)
                        {
                            if (obj.Age < 18)
                            {
                                throw new AgeException("Age shouldn’t be less than 18");
                            }
                            else if (obj.Age >= 18)
                            {
                                VoterList[i] = obj;
                                ISUpdated = true;
                                break;
                            }
                        }
                    }
                    catch (AgeException ex)
                    {
                        throw ex;
                    }
                    catch (Exception e)
                    {
                        Console.WriteLine(e.Message);
                    }
                     }            }
            return ISUpdated;
        }

        public Voter SearchVoter(string strVoterID)
        {
            Voter v=null;
            for(int i=0;i<VoterList.Count;i++)
            {
                if (VoterList[i].VoterID == strVoterID)
                {
                    v = VoterList[i] as Voter;
                }
                else
                    v = null;
            }
            return v;
        }

        public bool DeleteVoter(string strVoterID)
        {
            bool IsDeleted = false;
            for (int i = 0; i < VoterList.Count; i++)
            {
                if (VoterList[i].VoterID == strVoterID)
                {
                    IsDeleted = true;
                    break;
                }
                else
                   IsDeleted = false;
            }
            return IsDeleted;
        }

        public List<Voter> GetVoterList()
        {
            return VoterList;
        }
    }
}
