﻿using System;
using System.Collections.Generic;
using VoterEntry.Utility;
    using VoterEntry.Exceptions;
namespace VoterEntry

{
    public class VoterManagement
    {
        // TODO: Write your code here
        List<Voter> VoterList = new List<Voter>();
        public VoterManagement()
        {
            
            
        }

        public string AddVoter(Voter obj)
        {
            
            obj.Age = DateTime.Now.Subtract(obj.DateofBirth).Days/365;
            string check="";            
            if ((String.IsNullOrEmpty(obj.FirstName) || String.IsNullOrEmpty(obj.LastName) || String.IsNullOrEmpty(obj.DateofBirth.ToString()) || String.IsNullOrEmpty(obj.FathersName) ||
            String.IsNullOrEmpty(obj.Gender) || String.IsNullOrEmpty(obj.Address) || String.IsNullOrEmpty(obj.ConstituencyName)))
            {
                check= null;
            }
            else
            {
                
                    if (obj.Age < 18)
                    {
                        try
                        {
                            throw new AgeException("Age shouldn’t be less than 18");
                        }catch(Exception e)
                        {
                            Console.WriteLine(e.Message);
                        }                     

                    }
                    else if (obj.Age >= 18)
                    {
                    VoterUtility vu = new VoterUtility();
                    String VoterID = vu.GenerateVoterID(obj.FirstName, obj.LastName, obj.DateofBirth);                    
                    obj.VoterID = VoterID;
                    VoterList.Add(obj);
                    check= obj.VoterID;
                        
                    }               
                
            }

            return check;

        }

        public bool ModifyVoter(Voter obj)
        {
            obj.Age = DateTime.Now.Subtract(obj.DateofBirth).Days/365;
            bool ISUpdated = false;
            if ((String.IsNullOrEmpty(obj.FirstName) || String.IsNullOrEmpty(obj.LastName) || String.IsNullOrEmpty(obj.DateofBirth.ToString()) || String.IsNullOrEmpty(obj.FathersName) ||
                String.IsNullOrEmpty(obj.Gender) || String.IsNullOrEmpty(obj.Address) || String.IsNullOrEmpty(obj.ConstituencyName)))
            {
                ISUpdated = false;
            }
            else
            {
                if (obj.Age < 18)
                {
                    try
                    {
                        throw new AgeException("Age shouldn't be less than 18");
                    }
                    catch (Exception e)
                    {
                        Console.WriteLine(e.Message);
                    }
                }
                else if (obj.Age >= 18)
                {
                    for (int i = 0; i < VoterList.Count; i++)
                    {
                        if (VoterList[i].VoterID == obj.VoterID)
                        {
                            VoterList[i] = obj;
                            ISUpdated = true;
                            break;
                        }
                    }
                }
            }
            return ISUpdated;
        }

        public Voter SearchVoter(string strVoterID)
        {
            Voter v=null;
            for(int i=0;i<VoterList.Count;i++)
            {
                if (VoterList[i].VoterID == strVoterID)
                {
                    v = VoterList[i] as Voter;
                }
                else
                    v = null;
            }
            return v;
        }

        public bool DeleteVoter(string strVoterID)
        {
            bool IsDeleted = false;
            for (int i = 0; i < VoterList.Count; i++)
            {
                if (VoterList[i].VoterID == strVoterID)
                {
                    IsDeleted = true;
                    break;
                }
                else
                   IsDeleted = false;
            }
            return IsDeleted;
        }

        public List<Voter> GetVoterList()
        {
            return VoterList;
        }
    }
}
