﻿using System;
using VoterEntry.Utility;
namespace VoterEntry
{
    class Program
    {
        static void Main(string[] args)
        {
          /*  Voter voter = new Voter("John","Smith", "06/21/1999", "Max", "male", "231-RiverPark", "Lok Sabha constituency");
            VoterUtility vu = new VoterUtility();
            String VoterID = vu.GenerateVoterID(voter.FirstName, voter.LastName, voter.DateofBirth);
            voter.Age = DateTime.Now.Subtract(voter.DateofBirth).Days / 365;
            voter.VoterID = VoterID;
            VoterManagement VM = new VoterManagement();
            Console.WriteLine(VM.AddVoter(voter));
            VM.ModifyVoter(voter);
            VM.DeleteVoter(voter.VoterID);
            VM.SearchVoter(voter.VoterID);
            VM.GetVoterList();
            */
            
        }
    }
}
