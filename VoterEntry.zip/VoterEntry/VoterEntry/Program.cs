﻿using System;
using VoterEntry.Utility;
using System.Collections;
using System.Collections.Generic;

namespace VoterEntry
{
    class Program
    {
        static void Main(string[] args)
        {
            DateTime dateTime = new DateTime(1967, 4, 23);
            Voter voter = new Voter("John", "Stone", dateTime, "Max", "male", "231-RiverPark", "Lok Sabha constituency");            
            VoterManagement VM = new VoterManagement();
            string call = VM.AddVoter(voter);                       
            Console.WriteLine(call);
            // Console.WriteLine(VM.DeleteVoter(call));

            List<Voter> v = VM.GetVoterList();
            for (int i=0;i<v.Count;i++)
            {
                Console.WriteLine(v[i].FirstName);
            }


        }
    }
}
