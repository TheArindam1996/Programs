﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VoterEntry.Utility
{
    public class VoterUtility
    {
        public string GenerateVoterID(string strFirstName, string strLastName, DateTime dtDateofBirth)
        {
            
            int daynum = dtDateofBirth.Day;
            int month = dtDateofBirth.Month;
            int year = dtDateofBirth.Year;
            string day = dtDateofBirth.DayOfWeek.ToString();
            string str = strFirstName.ElementAt(0).ToString() + strLastName.ElementAt(0).ToString();
            str = str + day.ElementAt(0);
            str = str + (strFirstName.Length +""+strLastName.Length);
            str =str+ SumDigit(month)+ SumDigit(daynum) + SumDigit(year);
            //Console.WriteLine(str);
            return str;

        }

        string SumDigit(int value)
        {
            int temp = 0, sum = 0;
            while(value>0)
            {
                temp = value % 10;
                sum = sum + temp;
                value = value / 10;
            }
            return sum.ToString();
        }
    }
}
