﻿using System;
using System.Data.SqlClient;
using System.Linq;
namespace MovieTicketing
{
    public class TicketingDataAccess
    {
        string ConnectionString = "Data Source=.;Initial Catalog=MovieTicketing;User ID=sa;Password=wipro@123";
        Movies mov = null;
        public bool AddMovie(Movies obj)
        {
            bool IsAdded = false;
            if (obj==null)
            {
                IsAdded = false;
            }            
            SqlConnection con = new SqlConnection();
            con.ConnectionString = ConnectionString;
            SqlCommand cmd = new SqlCommand();
            cmd.CommandText = "insert into movies(movieid,moviename,director,playsperday,ticketprice) values(@mv,@mvn,@d,@play,@ticp) ";
           // cmd.Parameters.AddWithValue("@mv",obj.MovieID);
            cmd.Parameters.AddWithValue("@mvn", obj.MovieName);
            cmd.Parameters.AddWithValue("@d", obj.DirectorName);
            cmd.Parameters.AddWithValue("@play", obj.PlaysPerDay);
            cmd.Parameters.AddWithValue("@ticp", obj.TicketPrice);
            cmd.Connection = con;
            con.Open();
            int result = cmd.ExecuteNonQuery();
            if (result == 1)
                IsAdded = true;
            else
                IsAdded = false;

            mov = obj;
            return IsAdded;
        }

        public bool AddTheatre(Theatres obj)
        {
            bool IsAdded = false;
            if (obj == null)
            {
                IsAdded = false;
            }
            SqlConnection con = new SqlConnection();
            con.ConnectionString = ConnectionString;
            SqlCommand cmd = new SqlCommand();
            cmd.CommandText = "insert into theatres(theatreid,theatrename,seatingcapacity) values(@thid,@thn,@sc)";
//cmd.Parameters.AddWithValue("@thid", obj.TheatreId);
            cmd.Parameters.AddWithValue("@thn", obj.TheatreName);
            cmd.Parameters.AddWithValue("@sc", obj.SeatingCapacity);            
            cmd.Connection = con;
            con.Open();
            int result = cmd.ExecuteNonQuery();
            if (result == 1)
                IsAdded = true;
            else
                IsAdded = false;

            return IsAdded;
        }

        public bool AddShow(Shows obj)
        {
            bool IsAdded = false;
            if (obj == null)
            {
                IsAdded = false;
            }
            SqlConnection con = new SqlConnection();
            con.ConnectionString = ConnectionString;
            SqlCommand cmd = new SqlCommand();
            cmd.CommandText = "insert into shows(showid,theatreid,movieid,startdate,enddate,starttime,endtime) values(@shid,@thid,@mvid,@std,@end,@stt,@ent) ";
       //     cmd.Parameters.AddWithValue("@shid", obj.ShowId);
            cmd.Parameters.AddWithValue("@thid", obj.TheatreId);
            cmd.Parameters.AddWithValue("@mvid", obj.MoviId);
            cmd.Parameters.AddWithValue("@std", obj.StartDate);
            cmd.Parameters.AddWithValue("@end", obj.EndDate);
            cmd.Parameters.AddWithValue("@stt", obj.StartTime);
            cmd.Parameters.AddWithValue("@ent", obj.EndTime);
            cmd.Connection = con;
            con.Open();
            int result = cmd.ExecuteNonQuery();
            if (result == 1)
                IsAdded = true;
            else
                IsAdded = false;

            return IsAdded;
        }

        public string AddTicket(Tickets obj)
        {
            /*DateTime dt = obj.BookingDate;
            string s1 = mov.MovieName;
            string s2 = obj.CustomerName;
            string refer = "";
            string IsAdded ="";
            if (obj == null)
            {
                IsAdded = null;
            }
            refer += s2.ElementAt(0)+ s2.ElementAt(1)+obj.NumberofPersons;
            refer += s1.ElementAt(0) + s1.ElementAt(1)+dt.DayOfWeek+dt.DayOfYear;
            Random r = new Random();
            int n = r.Next(1,1000);
            refer += n;
            for(int i=0;i<refer.Length;i++)
            {
                if(char.IsLower(refer.ElementAt(i)))
                    refer=refer
            }
            */
            return "true";
        }


        public int DeleteMovie(int intMovieID)
        {
            return 1;
        }
    }
}
