﻿using System;


namespace MovieTicketing
{
    public class Tickets
    {
        public int TicketId { set; get; }
        public int ShowId { set; get; }
        public string CustomerName { set; get; }
        public string ReferenceCode { set; get; }
        public DateTime BookingDate { set; get; }
        public int NumberofPersons { set; get; }
        public decimal Amount { set; get; }
        public string TicketStatus { set; get; }
    }
}
