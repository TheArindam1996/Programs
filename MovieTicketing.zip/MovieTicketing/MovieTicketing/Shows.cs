﻿using System;


namespace MovieTicketing
{
    public class Shows
    {
       public int ShowId { set; get; }
        public int TheatreId { set; get; }
        public int MoviId { set; get; }
        public DateTime StartDate { set; get; }
        public DateTime EndDate { set; get; }
        public DateTime StartTime { set; get; }
        public DateTime EndTime { set; get; }
    }
}
