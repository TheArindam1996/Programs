﻿using System;


namespace MovieTicketing
{
    public class Tickets
    {
        public int TicketID { set; get; }
        public int ShowID { set; get; }
        public string CustomerName { set; get; }
        public string ReferenceCode { set; get; }
        public DateTime BookingDate { set; get; }
        public int NumberofPersons { set; get; }
        public decimal Amount { set; get; }
        public string TicketStatus { set; get; }
    }
}
