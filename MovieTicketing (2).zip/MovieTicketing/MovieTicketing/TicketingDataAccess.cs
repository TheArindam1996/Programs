﻿using System;
using System.Data.SqlClient;
using System.Linq;
namespace MovieTicketing
{
    public class TicketingDataAccess
    {
        string ConnectionString = "Data Source=.;Initial Catalog=MovieTicketing;User ID=sa;Password=wipro@123";        
        public bool AddMovie(Movies obj)
        {
            bool IsAdded = false;

            if (obj != null)
            {
                SqlConnection con = new SqlConnection();
                con.ConnectionString = ConnectionString;
                SqlCommand cmd = new SqlCommand();
                cmd.CommandText = "insert into movies(moviename,director,playsperday,ticketprice) values(@mvn,@d,@play,@ticp) ";
                cmd.Parameters.AddWithValue("@mvn", obj.MovieName);
                cmd.Parameters.AddWithValue("@d", obj.DirectorName);
                cmd.Parameters.AddWithValue("@play", obj.PlaysPerDay);
                cmd.Parameters.AddWithValue("@ticp", obj.TicketPrice);
                cmd.Connection = con;
                con.Open();
                int result = cmd.ExecuteNonQuery();
                con.Close();
                if (result == 1)
                    IsAdded = true;
                else
                    IsAdded = false;

               
            }
            else
            {
                IsAdded = false;
            }
            return IsAdded;
        }

        public bool AddTheatre(Theatres obj)
        {
            bool IsAdded = false;
            if (obj != null)
            {
                SqlConnection con = new SqlConnection();
                con.ConnectionString = ConnectionString;
                SqlCommand cmd = new SqlCommand();
                cmd.CommandText = "insert into theatres(theatrename,seatingcapacity) values(@thn,@sc)";
                cmd.Parameters.AddWithValue("@thn", obj.TheatreName);
                cmd.Parameters.AddWithValue("@sc", obj.SeatingCapacity);
                cmd.Connection = con;
                con.Open();
                int result = cmd.ExecuteNonQuery();
                con.Close();
                if (result == 1)
                    IsAdded = true;
                else
                    IsAdded = false;
            }
            else
            {
                IsAdded = false;
            }

            return IsAdded;
        }

        public bool AddShow(Shows obj)
        {
            bool IsAdded = false;
            if (obj != null)
            {
                SqlConnection con = new SqlConnection();
                con.ConnectionString = ConnectionString;
                SqlCommand cmd = new SqlCommand();
                cmd.CommandText = "insert into shows(theatreid,movieid,startdate,enddate,starttime,endtime) values(@thid,@mvid,@std,@end,@stt,@ent) ";
                cmd.Parameters.AddWithValue("@thid", obj.TheatreID);
                cmd.Parameters.AddWithValue("@mvid", obj.MoviID);
                cmd.Parameters.AddWithValue("@std", obj.StartDate);
                cmd.Parameters.AddWithValue("@end", obj.EndDate);
                cmd.Parameters.AddWithValue("@stt", obj.StartTime);
                cmd.Parameters.AddWithValue("@ent", obj.EndTime);
                cmd.Connection = con;
                con.Open();
                int result = cmd.ExecuteNonQuery();
                if (result == 1)
                    IsAdded = true;
                else
                    IsAdded = false;
            }
            else
            {
                IsAdded = false;
            }

            return IsAdded;
        }

        public string AddTicket(Tickets obj)
        {
            string str = null;
            if(obj != null)
            {
                string moviename = "";
                decimal ticketprice = 0;
                string refcode = "";
                string cust = obj.CustomerName;
                SqlConnection sql = new SqlConnection(ConnectionString);
                SqlCommand cmd = new SqlCommand("select m.moviename,m.ticketprice from movies m join shows s on m.movieid=s.movieid join tickets t on s.showid=t.showid where t.showid=@shid",sql);
                cmd.Parameters.AddWithValue("@shid",obj.ShowID);
                
                sql.Open();
                SqlDataReader dr = cmd.ExecuteReader();                
                if(dr.HasRows)
                {
                    while(dr.Read())
                    {
                        moviename = dr["moviename"].ToString();
                        ticketprice = decimal.Parse(dr["ticketprice"].ToString());
                    }
                }
                sql.Close();
                refcode = cust[0]+ cust[1]+obj.NumberofPersons.ToString()+moviename[0]+moviename[1]+obj.BookingDate.Day.ToString()+obj.BookingDate.Month.ToString();
                Random r = new Random();
               int rand= r.Next(1,1000);
                refcode = refcode + rand.ToString();
                refcode = refcode.ToUpper();
                obj.ReferenceCode = refcode;
                obj.Amount = ticketprice * obj.NumberofPersons;
                SqlCommand cmd1 = new SqlCommand("insert into tickets(showid,referencecode,customername,numberofpersons,bookingdate,amount,ticketstatus) values (@sid,@ref,@cust,@num,@bookd,@am,@ticket)",sql);
                cmd1.Parameters.AddWithValue("@sid",obj.ShowID);
                cmd1.Parameters.AddWithValue("@ref", obj.ReferenceCode);
                cmd1.Parameters.AddWithValue("@cust", obj.CustomerName);
                cmd1.Parameters.AddWithValue("@num", obj.NumberofPersons);
                cmd1.Parameters.AddWithValue("@bookd",obj.BookingDate);
                cmd1.Parameters.AddWithValue("@am", obj.Amount);
                cmd1.Parameters.AddWithValue("@ticket", obj.TicketStatus);                
               
                sql.Open();
                int row = cmd1.ExecuteNonQuery();
                sql.Close();
                if(row==1)
                {
                    str = obj.ReferenceCode;
                }
                
            }
            else
            {
                str=null;
            }
            return str;
        }


        public int DeleteMovie(int intMovieID)
        {
            int rowsdeleted = 0;
            
            SqlConnection con = new SqlConnection(ConnectionString);
            SqlCommand cmd = new SqlCommand("select showid from shows where movieid=@mvid",con);
            cmd.Parameters.AddWithValue("@mvid",intMovieID);
            con.Open();
            SqlDataReader data = cmd.ExecuteReader();
            if(data.HasRows)
            {
                
                while(data.Read())
                {
                    int showId = int.Parse(data["showid"].ToString());
                    SqlConnection con1 = new SqlConnection(ConnectionString);
                    SqlCommand cmd1 = new SqlCommand("delete from tickets where showid=@shid",con1);
                    con1.Open();
                    cmd1.Parameters.AddWithValue("@shid", showId);
                    int gotrows = cmd1.ExecuteNonQuery();
                    con1.Close();
                    rowsdeleted += gotrows ;
                }
            }


            con.Close();


            
            SqlCommand cmd2 = new SqlCommand("delete from shows where movieid=@mvid", con);
                    con.Open();
                    cmd2.Parameters.AddWithValue("@mvid", intMovieID);
                    int n=cmd2.ExecuteNonQuery();
                    rowsdeleted += n;
                
            
            con.Close();
            
            SqlCommand cmd3 = new SqlCommand("delete from movies where movieid=@mvid", con);
            con.Open();
            cmd3.Parameters.AddWithValue("@mvid", intMovieID);
            int m=cmd3.ExecuteNonQuery();
            rowsdeleted += m;
            con.Close();

            return rowsdeleted;
        }
    }
}
