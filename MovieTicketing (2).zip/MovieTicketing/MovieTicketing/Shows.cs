﻿using System;


namespace MovieTicketing
{
    public class Shows
    {
       public int ShowID { set; get; }
        public int TheatreID { set; get; }
        public int MoviID { set; get; }
        public DateTime StartDate { set; get; }
        public DateTime EndDate { set; get; }
        public DateTime StartTime { set; get; }
        public DateTime EndTime { set; get; }
    }
}
