﻿using System;


namespace MovieTicketing
{
    public class Theatres
    {
        //TODO: Write Code here
    }
}
