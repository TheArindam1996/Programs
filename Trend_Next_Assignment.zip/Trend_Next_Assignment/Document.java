import java.util.*;
public class Document {

    public  String text;

    public String toString() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }   

}

class Email extends Document
{
    private String sender;
    private String recipient;
    private String title;

    public String getSender() {
        return sender;
    }

    public void setSender(String sender) {
        this.sender = sender;
    }

    public String getRecipient() {
        return recipient;
    }

    public void setRecipient(String recipient) {
        this.recipient = recipient;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

   @Override
    public String toString() {
        return "Email{" + "sender=" + sender + ", recipient=" + recipient + ", title=" + title +" text="+text+ "}";
    }    
}

class Call2
{
    public static void main(String[] args) 
    {
        Email email = new Email();
        email.setSender("Max");
        email.setRecipient("Michel");
        email.setTitle("Document");
        email.text="This document is encrypted";
        System.out.println(email.toString());
    }
}

