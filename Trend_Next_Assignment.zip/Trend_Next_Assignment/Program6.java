import java.util.*;
public class Program6 {
	public static void main(String args[])
	{
		Scanner sc = new Scanner(System.in);
		int arr[] = new int[10];
		for(int i=0;i<arr.length;i++)
		{
			arr[i] = sc.nextInt();
		}
		int max = arr[0],temp=0;
		for(int j=0;j<arr.length;j++)
		{
			if(max<arr[j])
			{
				max = arr[j];
			}
		}
		System.out.println(max);
	}
}
