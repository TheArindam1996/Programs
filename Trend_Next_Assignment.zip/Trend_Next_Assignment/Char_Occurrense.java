
import java.util.Scanner;


class Char_Occurrence 
{
    public static void main(String[] args) 
    {
        Scanner sc = new Scanner(System.in);
        String str = sc.nextLine();
        String c = sc.nextLine();
        int len = str.replace(c, "").length();
        int length = str.length()-len;
        System.err.println("occurrence of "+c+" is "+length);
    }
}
