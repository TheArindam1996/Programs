import java.util.*;
public class HashSet_Demo 
{
    public static void main(String[] args) 
    {
        HashSet ht = new HashSet();
        ht.add("Max");
        ht.add("Meera");
        ht.add("Daniel");
        ht.add("Seatin");
        ht.add("Carol");
        ht.add("Samuel");
        ht.add("Robert");
        ht.add("Scarlet");
        
        Iterator iterator = ht.iterator();
        while(iterator.hasNext())
        {
            System.err.println(iterator.next());
        }       
    }
}
