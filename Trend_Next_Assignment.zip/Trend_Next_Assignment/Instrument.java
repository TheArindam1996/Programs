
public abstract class Instrument 
{
    abstract String play();
}

class Piano extends Instrument
{
    public String play()
    {
        return "Piano is playing tan tan tan tan  ";
    }
}

class Flute extends Instrument
{
    public String play()
    {
        return "Flute is playing toot toot toot toot";
    }
}

class Guitar extends Instrument
{
    public String play()
    {
        return "Guitar is playing tin tin tin";
    }
}

class Call3
{
    public static void main(String[] args) 
    {
        Instrument ins[] = {new Guitar(),new Flute(),new Flute(),new Guitar(),new Piano(),new Piano()
                ,new Guitar(),new Flute(),new Flute(),new Piano()};
        
        for(int i=0;i<ins.length;i++)
        {
            if(ins[0] instanceof Piano)
            {
                System.err.println(ins[i].play()+" is the object of Piano and stored at index - "+i);
            }
            else if (ins[0] instanceof Flute)
            {
                System.err.println(ins[i].play()+" is the object of Flute and stored at index - "+i);
            }
            else if(ins[0] instanceof Guitar)
            {
                System.err.println(ins[i].play()+" is the object of Guitar and stored at index - "+i);
            }
        }
    }            
}