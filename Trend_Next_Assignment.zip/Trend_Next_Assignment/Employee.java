
import java.util.ArrayList;
import java.util.Scanner;


public class Employee 
{
    public String name;
    public String city;
    public int empid;
    public double salary;       

    public Employee(String name, String city, int empid, double salary) 
    {
        this.name = name;
        this.city = city;
        this.empid = empid;
        this.salary = salary;
    }

    
    
}

class EmployeeDB
{
    ArrayList<Employee> al = null;
    boolean addEmployee(Employee emp)
    {                     
        al  = new ArrayList<Employee>();  
        al.add(emp);
        return true;
    }
    
    boolean deleteEmployee(int eCode)
    {
        boolean IsDeleted = false;
        for(int i=0;i<al.size();i++)
        {            
            if(al.get(i).empid == eCode)
            {
                al.remove(i);
                IsDeleted = true;
            }
                
        }
        return IsDeleted;
    }
    
    String showPaySlip(int eCode)
    {                
        String paySlip = null;
        for(int i=0;i<al.size();i++)
        {
            if(al.get(i).empid == eCode)
                paySlip = "salary is "+al.get(i).salary;
        }
        return paySlip;
    }    
    
    ArrayList<Employee> listAll()
    {
        return al;
    }
}

