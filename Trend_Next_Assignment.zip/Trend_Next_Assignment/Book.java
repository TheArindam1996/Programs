public class Book {
     public String isbn;
     public String title;
     public int price;     

    public String getIsbn() {
        return isbn;
    }

    public String getTitle() {
        return title;
    }

    public int getPrice() {
        return price;
    }
     
}

class Magazine extends Book
{
    String type;
    
    Magazine(String isbn,String title,int price,String type)
    {
        this.isbn = isbn;
        this.title = title;        
        this.type = type;
        this.price = price;        
    }
    
}

class Novel extends Book
{
    String author;
    
    Novel(String isbn,String title,int price,String author)
    {
        this.isbn = isbn;
        this.title = title;        
        this.author = author;
        this.price = price;
    }
}

class Call 
{
    public static void main(String[] args) 
    {
        
        Magazine mz = new Magazine("978-7856-5959-68",
        "India Today",120,"Awareness");
        System.out.println("Title = "+mz.title+" Isbn = "+mz.isbn
                +" Type = "+mz.type+" Price = "+mz.price);
        Novel nv = new Novel("98989808","Life is what you make it",129,"Preeti Shinoy");
        System.out.println("Title = "+nv.title+" Isbn = "+nv.isbn
        +" Author = "+nv.author+" Price = "+nv.price);
    }
}