
public class Program2 {
	public static void main(String args[])
	{
		int a=-5,b=8,c=6,result=0;
		result = a+b*c;
		System.out.println(result);
		a=55;
		b=9;
		c=9;
		result=(a+b)%c;
		System.out.println(result);
		int d=8;
		a=20;
		b=-3;
		c=5;
		result = a+b*c/d;
		System.out.println(result);
		a=5;
		b=15;
		c=2;
		d=8;
		result = a+b/3*c-d%3;
		System.out.println(result);
	}
}
