class Exceptions_Demo2
{
	void method(String name,String num1,String num2,String num3)
	{
		try{
	
		int count = 0;
		for(int i=0;i<num1.length();i++)
		{
			if(Character.isLetter(num1.charAt(i)))
			{
				throw new NumberFormatException();
				//break;
			}												
		}	
		for(int i=0;i<num2.length();i++)
		{
			if(Character.isLetter(num2.charAt(i)))
			{
				throw new NumberFormatException();
				//break;
			}												
		}	
		for(int i=0;i<num3.length();i++)
		{
			if(Character.isLetter(num3.charAt(i)))
			{
				throw new NumberFormatException();
				//break;
			}												
		}	

			int avg = (Integer.parseInt(num1)+Integer.parseInt(num2)+Integer.parseInt(num3))/3;
			System.out.println(name+" "+avg);

		}
		catch(Exception e)
		{
			if(e.equals(e))
			System.out.println("Invalid Number");
		}
	}
	
	public static void main(String args[])
	{
		Exceptions_Demo2 excp = new Exceptions_Demo2();
		excp.method(args[0],args[1],args[2],args[3]);
	}
}