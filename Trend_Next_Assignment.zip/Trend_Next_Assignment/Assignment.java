public class Assignment
{
	String conCat(String str,String str1)
	{
		return str+" Technologies "+str1;	
	}
	public static void main(String args[])
	{
		Assignment ags 	= new Assignment();
		System.out.println(ags.conCat(args[0],args[1]));
	}
}