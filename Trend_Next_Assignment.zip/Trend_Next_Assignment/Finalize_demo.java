
public class Finalize_demo 
{
    protected void finalize()
    {
        System.err.println("Finalize method called");
    }
}

class Call_finalize
{
    public static void main(String[] args) 
    {
        Finalize_demo finalize_demo = new Finalize_demo();
        finalize_demo = new Finalize_demo();
        finalize_demo = new Finalize_demo();
        Runtime.getRuntime().gc();
    }
}
