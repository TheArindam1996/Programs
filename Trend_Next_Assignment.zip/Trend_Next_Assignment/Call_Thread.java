
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class Call_Thread
{
    public static void main(String[] args) 
    {
        try
        {
            for(int i=0;i<20;i++)
            {
                DateTimeFormatter df = DateTimeFormatter.ofPattern("HH:mm:ss");
                LocalDateTime now = LocalDateTime.now();
                System.err.println(df.format(now));
                Thread.sleep(2000);
            }
        }catch(InterruptedException e)
        {
            
        }
    }
}