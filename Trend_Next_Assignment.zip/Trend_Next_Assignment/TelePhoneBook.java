
import java.util.*;
public class TelePhoneBook 
{
    public static void main(String[] args) 
    {
        HashMap<String , String> hashMap = new HashMap<String , String>();
        hashMap.put("Max", "9956136569");
        hashMap.put("Meera", "9956136545");
        hashMap.put("Daniel", "9956136334");
        hashMap.put("Seatin", "9956136234");
        hashMap.put("Carol", "9956136569");
        hashMap.put("Samuel", "9956136545");
        hashMap.put("Robert", "9956136334");
        hashMap.put("Scarlet", "9956136234");       
        
        Scanner sc = new Scanner(System.in);
        String get = sc.nextLine();
        String st =hashMap.get(get);
        if(st == null)
            System.out.println("Not found int the telephonedirectory");
        else
            System.out.println(st);
    }
}
