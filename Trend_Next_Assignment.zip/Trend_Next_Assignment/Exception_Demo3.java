class Exception_Demo3
{
	void method()
	{
		
	}
	public static void main(String args[])
	{
		int sum = 0;
		double length = args.length;
		try
		{
			if(args.length < 5)
			throw new ArrayIndexOutOfBoundsException();

			else
			{
				for(int i = 0;i<args.length;i++)
				{
					sum+=Integer.parseInt(args[i]);
				}
				double avg = sum/length;
				System.out.println(avg);
			}
		}		
		catch(ArrayIndexOutOfBoundsException ae)
		{
			if(ae.equals(ae))
			System.out.println("length is less than 5");
		}
	}
}