import java.util.*;

 class Book {
	
	String isbn;
	String title;
	String author;
	float price;
	
	Book(String isbn,String title,String author,int price)
	{
		this.isbn=isbn;
		this.title=title;
		this.author=author;
		this.price=price;
	}
	void displaydeta()
	{
		System.out.println("Isbn - "+isbn);
		System.out.println("Title - "+title);
		System.out.println("Author - "+author);
		System.out.println("Price - "+price);
	}
	
	float discountedprice(float discountpercent)
	{
		return price = (price - price * (discountpercent/100));
		
	}
	
	public static void main(String[] args)
	{
		Scanner sc = new Scanner(System.in);		
		Book book = new Book(sc.nextLine(),sc.nextLine(),sc.nextLine(),sc.nextInt());
		book.discountedprice(sc.nextFloat());
		book.displaydeta();
	}
}
