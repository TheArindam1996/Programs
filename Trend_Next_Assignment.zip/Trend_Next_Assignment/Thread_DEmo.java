
public class Thread_DEmo 
{
    public static void main(String[] args) 
    {
        Thread1 th1 = new Thread1();
        Thread d1 = new Thread(th1);
        d1.start();        
        Thread2 th2 = new Thread2();
        Thread d2 = new Thread(th2);
        d2.start();
    }
    
    void run()
    {
        
    }
}

class Thread1 implements Runnable
{
    static int random = 0;
    public void run()
    {
        random = (int)(Math.random()*10);
        System.err.println(random); 
        Thread2 d2 = new Thread2();
        d2.call(random);
    }
}


class Thread2 implements Runnable
{
     static int get = 0 ;
    void call(int n)
    {
       // System.err.println(n);
        this.get = n;
      //  System.err.println(get);
    }
    
    public void run()
    {
        int prod = 1;
        System.err.println("value of get is "+get);
        for(int i=1;i<=get;i++)
        {
            prod*=i;
        }
        System.err.println(prod);
    }
}
        
    
