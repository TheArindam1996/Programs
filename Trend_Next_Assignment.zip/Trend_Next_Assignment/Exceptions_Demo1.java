public class Exceptions_Demo1
{
	void method(String name,int age)
	{
		try
		{
		
			if(age >= 18 && age < 60)
			{
				System.out.println(name+" "+age);
			}
			else 
			{
				throw new AgeException("Invalid Age");
			}
		}
		catch(AgeException ae)
		{
			System.out.println(ae);
		}
	}
	public static void main(String args[])
	{
		new Exceptions_Demo1().method(args[0],Integer.parseInt(args[1]));	
	}

}

class AgeException extends Exception
{
	AgeException(String msg)
	{
		super(msg);	
	}
}
