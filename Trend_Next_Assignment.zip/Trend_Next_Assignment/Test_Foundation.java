//package Test;

import Test.foundation;


public class Test_Foundation extends foundation
{
    public static void main(String[] args) 
    {
        foundation f = new foundation();
        int i = Var3;
    }
}
