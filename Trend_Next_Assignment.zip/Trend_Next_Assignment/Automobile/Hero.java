
package Automobile;

public class Hero extends Vechile
{
    @Override
    public String modelName()
    {
        return "";
    }

    @Override
    public String registrationNumber() 
    {
        return "";
    }

    @Override
    public String ownerName() 
    {
        return "";
    }
    
    public int speed()
    {
        return 2;
    }
    
    public void radio()
    {
        
    }
    
}
