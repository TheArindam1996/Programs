
package Automobile;

public abstract class Vechile 
{
    public abstract String modelName();
    
    public abstract String registrationNumber();
    
    public abstract String ownerName();
    
}
