
package Automobile;

public class Honda extends Vechile
{

    @Override
    public String modelName() 
    {
        return "";
    }

    @Override
    public String registrationNumber() 
    {
        return "";
    }

    @Override
    public String ownerName() 
    {
        return "";
    }
    
    public int speed()
    {
        return 3;
    }
    
    public int cdPlayer()
    {
        return 1;
    }
}
