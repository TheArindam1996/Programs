package Live;

import Music.Playable;
import Music.string.*;
import Music.wind.*;

public class Test {

    public static void main(String[] args) {
        Veena v = new Veena();
        v.play();

        Saxophone saxPhone = new Saxophone();
        saxPhone.play();

        Playable p = saxPhone;
        p.play();
        p = v;
        p.play();
    }
}
