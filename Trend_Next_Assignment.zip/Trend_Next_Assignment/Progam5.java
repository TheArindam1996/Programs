import java.util.*;

public class Progam5 {
	public static void main(String args[])
	{
		Scanner sc = new Scanner(System.in);
		int get = sc.nextInt();
		int sum=0,temp=0;
		while(get>0)
		{
			temp = get%10;
			sum+=temp;
			get/=10;
		}
		System.out.println(sum);
	}
}
