import java.util.*;

public class Program3 {
	public static void main(String args[])
	{
		Scanner sc = new Scanner(System.in);
		int year_day = sc.nextInt(),count=0,check=0;
		year_day = year_day/24;
		year_day = year_day/60;
		while(year_day>365)
		{
			check = year_day%365;
			count++;
			if(check==0)
			{
				//System.out.println(year_day/365);
				break;
			}
			year_day = year_day-365;
			
		}	
		System.out.println(count+" year "+check+ " days");
	}
}
