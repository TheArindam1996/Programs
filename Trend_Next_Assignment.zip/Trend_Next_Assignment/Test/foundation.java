package Test;

public class foundation 
{
    static private int Var1;
    static int Var2;
    static protected int Var3;
    static public int Var4;    
}
