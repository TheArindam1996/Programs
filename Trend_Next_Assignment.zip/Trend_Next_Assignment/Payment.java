import java.util.*;

public class Payment 
{
    private double amount;

    public double getAmount() {
        return amount;
    }

    public void setAmount(double amount) {
        this.amount = amount;
    }
    
    String paymentDetails()
    {
        return "The amount of the payment is ";
    }
}
class CashPayment extends Payment
{
    
    @Override
    String paymentDetails()
    {
        return "payment is " +getAmount()+" which has been made in cash";
    }
    CashPayment(double amount)
    {
        setAmount(amount);
    }
}

class CreditCardPayment extends Payment
{
    String name;
    Calendar expirydate ;
    String creditcardnumber;

    public CreditCardPayment(String name, Calendar expirydate, String creditcardnumber,double amount) 
    {
        this.name = name;
        this.expirydate = expirydate;        
        this.creditcardnumber = creditcardnumber;
        setAmount(amount);
    }
    
    @Override
    String paymentDetails()
    {
        return "CreditCardPayment{" + "name=" + name + ", expirydate=" + expirydate.getTime() + ", creditcardnumber=" + creditcardnumber + "Amount = "+getAmount()+" }";
    }
    
}

class Call1
{
    public static void main(String[] args) 
    {
        Calendar cal = Calendar.getInstance();
        cal.set(Calendar.MONTH, 9);
        cal.set(Calendar.YEAR, 2023);
        CashPayment cp = new CashPayment(2767.88);
        System.out.println(cp.paymentDetails());
        CashPayment cp1 = new CashPayment(3534.322);               
        System.out.println(cp1.paymentDetails());
        CreditCardPayment ccp = new CreditCardPayment("Sam", cal, "501234567894",23456);
        System.out.println(ccp.paymentDetails());
        Calendar cal1 = Calendar.getInstance();
        cal1.set(Calendar.MONTH, 2);
        cal1.set(Calendar.YEAR, 2033);
        CreditCardPayment ccp1 = new CreditCardPayment("Max", cal1, "501234567894",12345.67);
        System.out.println(ccp1.paymentDetails());
    }
}