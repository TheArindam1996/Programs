﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssetManagement
{
    class Employee
    {
        public string EmployeeID { get; set; }
        public string EmployeeName { get; set; }
        public DateTime DateofJoining { get; set; }
        public string Email { get; set; }
        public string Location { get; set; }
        public long Phone { get; set; }
    }
}
