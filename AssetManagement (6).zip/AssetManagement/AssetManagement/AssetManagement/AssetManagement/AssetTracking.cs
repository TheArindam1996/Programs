﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssetManagement
{
    public class AssetTracking
    {
        const string ConnectionString = "Data Source=.;Initial Catalog=AssetManagement;User ID=sa;Password=wipro@123";
        public bool AddAsset(Asset obj)
        {
            string asset = "";
            Random r = new Random();
            int r1 = r.Next(1,1000);
            asset = obj.AssetType[0].ToString() + obj.AssetType[1].ToString();
            asset += r1.ToString();
            if (obj != null)
            {
                SqlConnection con1 = new SqlConnection(ConnectionString);
                con1.Open();
                SqlCommand cmd1 = new SqlCommand("insert into asset(assettype,serialno,procurementdate,taggingstatus) values(@at,@sno,@pdate,@ts)", con1);
                cmd1.Parameters.AddWithValue("@at", asset);
                cmd1.Parameters.AddWithValue("@sno", obj.SerialNo);
                cmd1.Parameters.AddWithValue("@pdate", DateTime.Now);
                cmd1.Parameters.AddWithValue("@ts", "Free Pool");
                int row = cmd1.ExecuteNonQuery();
                con1.Close();
                if (row == 1)
                {
                    return true;
                }
                else
                    return false;
            }
            else
                return false;                
        }

        public bool ModifyAsset(Asset obj)
        {
            if (obj != null)
            {
                SqlConnection con2 = new SqlConnection(ConnectionString);
                con2.Open();
                SqlCommand cmd2= new SqlCommand("update asset set assettype=@at,serialno=@sno,procurementdate=@pd where assetid=@aid", con2);
                cmd2.Parameters.AddWithValue("@at", obj.AssetType);
                cmd2.Parameters.AddWithValue("@sno", obj.SerialNo);
                cmd2.Parameters.AddWithValue("@pd", obj.ProcurementDate);                
                int row = cmd2.ExecuteNonQuery();
                con2.Close();
                if (row == 1)
                {
                    return true;
                }
                else
                    return false;
            }
            else
                return false;
        }

        public bool TagAsset(AssetTagging obj)
        {
            if (obj != null)
            {
                SqlConnection con3 = new SqlConnection(ConnectionString);
                con3.Open();
                SqlCommand cmd3 = new SqlCommand("insert assettagging(employeeid,assetid,taggingdate,releasedate) values (@empid,@aid,@td,@rd)", con3);
                cmd3.Parameters.AddWithValue("@empid", obj.EmployeeID);
                cmd3.Parameters.AddWithValue("@aid", obj.AssetID);
                cmd3.Parameters.AddWithValue("@td", obj.TaggingDate);
                cmd3.Parameters.AddWithValue("@rd", obj.ReleaseDate);
                int row = cmd3.ExecuteNonQuery();
                con3.Close();
                if (row == 1)
                {
                    return true;
                }
                else
                    return false;
            }
            else
                return false;
        }

        public bool DeTagAsset(int intAssetId)
        {
            bool isup= false;
            if (intAssetId == 0)
                isup = false;
            else
            isup = true;

            return isup;
                
        }
    }
}
