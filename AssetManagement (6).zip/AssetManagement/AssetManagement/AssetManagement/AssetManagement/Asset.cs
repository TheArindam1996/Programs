﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssetManagement
{
    public class Asset
    {
        public int AssetID { get; set; }
        public string AssetType{ get; set; }
        public string SerialNo { get; set; }
        public DateTime ProcurementDate { get; set; }
        public string TaggingStatus { get; set; }
    }
}
