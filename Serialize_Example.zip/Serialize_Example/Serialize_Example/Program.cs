﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
using System.Threading.Tasks;

namespace Serialize_Example
{
    class Program
    {
        static void Main(string[] args)
        {
            S1 s = new S1();
            s.str = "Hello!, How are you.";
            s.d = 12.8;
            s.l = 10;
            BinaryFormatter bf = new BinaryFormatter();
            FileStream fs = new FileStream("Demo2.txt",FileMode.Create);
            bf.Serialize(fs,(s.str+" "+s.d+" "+s.l));
            fs.Close();
            FileStream fs1 = new FileStream("Demo2.txt", FileMode.Open);
            string s2=(string)bf.Deserialize(fs1);
            Console.WriteLine(s2);
            fs1.Close();
            

        }
    }

    [Serializable]
    class S1
    {
        public string str = "";
        public double d = new double();
        public long l = new long();
    }
}
